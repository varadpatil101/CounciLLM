# CounciLLM

CounciLLM is a fully local multi-model council backed by the LM Studio llama.cpp runtime that is already installed on this machine.

Project layout:

- `frontend/` contains the existing HTML UI, preserved and wired to the backend API.
- `backend/` contains the offline server and local model launcher.
- `config/council.json` lists the discovered local GGUF files and the LM Studio runtime settings.

Used local models:

- `qwen3-router` for routing and intent classification.
- `qwen3-general` for general responses.
- `granite-coding` for coding and implementation tasks.
- `qwen3-vision` for vision-capable requests, with its paired `mmproj` file.

What the backend does:

- Serves the frontend from the same local server.
- Exposes `GET /api/health`, `GET /api/models`, `GET /api/state`, and `POST /api/chat`.
- Starts `llama-server.exe` from the local LM Studio installation on demand.
- Routes requests automatically through the router model unless the UI asks for a specific role.

Run it:

```powershell
cd C:\Users\Varad\Documents\Codex\2026-08-28\referenced-chatgpt-conversation-this-is-an\CounciLLM
python backend\server.py
```

Then open:

```text
http://127.0.0.1:8765
```

Notes:

- This environment could not write directly to `Downloads`, so the project was created in the writable workspace instead.
- The project uses the local LM Studio `llama-server.exe` binaries already installed on the machine.
